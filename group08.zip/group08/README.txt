
"java -jar OnlineGame.jar"
Registriert zwei Agents und l�sst sie auf http://134.93.143.155:6008/game.html
gegeneinander Spielen.
Die main ist in OnlinePlayer.java.

Tests.java enth�lt methoden zum lokalen testen.

Zum compilieren wird das library json-20140107.jar ben�tigt.
.project ist die eclipse project datei.
