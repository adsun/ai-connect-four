import genericSearchProblem.Action;
import genericSearchProblem.State;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;


public class Tests {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//State[][][][] results = new State[2][2][8][8];
		//analyseAIs();
		//AiVsPlayer(654,6);
		System.out.println("Runnig");
		aiVsAi(2, 4, 6, 6);
		//AiVsRandom(6, 5);
		
	}
	
	public static void AiVsRandom(int difficulty, int maxDepth){
		ConnectFourProblem problem = new ConnectFourProblem(ConnectFourState.FieldState.RED, difficulty);
		AlphaBetaSearch player = new AlphaBetaSearch(problem, maxDepth);
		
		Action action;
		ConnectFourState currentState = (ConnectFourState) problem.getInitialState();
		Random random = new Random();
		int i = 0;
		boolean running = true;
		while(running){
			System.out.println("Step: "+i);
			//System.out.println("Current State: ");
			//long startTime = System.currentTimeMillis();

			//RandomTurn turn
			ArrayList<Action> actions = problem.getActions(currentState);
			action = actions.get(random.nextInt(actions.size()));
			currentState = (ConnectFourState) action.execute(currentState);
			if(problem.goalTest(currentState)){
				System.out.println("Random Wins!");
				System.out.println(currentState.toString());
				return;
			}
			//System.out.println("TurnA");
			problem.experimentingUtility(currentState, true);
			System.out.println(currentState.toString());
			
			//AI turn
			action = player.search(currentState);
			currentState = (ConnectFourState) action.execute(currentState);
			if(problem.goalTest(currentState)){
				System.out.println("AI Wins!");
				System.out.println(currentState.toString());
				return;
			}
			//System.out.println("TurnB");
			problem.experimentingUtility(currentState, true);
			System.out.println(currentState.toString());
			
			//Check if the field is full
			boolean foundEmpty = false;
			for(int column = 0; column < 7; column++){
				for(int row = 0; row < 6; row++){
					if(currentState.grid[column][row] == ConnectFourState.FieldState.EMPTY){
						foundEmpty = true;
						break;
					}
				}
			}
			if(!foundEmpty) running = false;
			i++;
		}
		
		System.out.println("Draw");
		return;
		
	}
	
	public static void AiVsPlayer(int difficulty, int maxDepth){
		ConnectFourProblem problemA = new ConnectFourProblem(ConnectFourState.FieldState.RED,difficulty);
		AlphaBetaSearch playerA = new AlphaBetaSearch(problemA, maxDepth);
		
		ConnectFourProblem problemB = new ConnectFourProblem(ConnectFourState.FieldState.YELLOW , 654);
		
		Scanner scanner = new Scanner(System.in);
		
		State currentState = problemA.getInitialState();

		Action action;
		
		for(int i = 0; i < 100; i++){
			System.out.println("Step: "+i);
			//System.out.println("Current State: ");
			//long startTime = System.currentTimeMillis();

			//PlayerA turn
			action = playerA.search(currentState);
			currentState = action.execute(currentState);
			if(problemA.goalTest(currentState)) break;
			
			System.out.println("TurnA");
			problemA.experimentingUtility(currentState, true);
			System.out.println(currentState.toString());

			
			//Player turn
			System.out.println("Choose column: ");
			action = problemB.actions.get(scanner.nextInt());
			System.out.println("Chose: "+action.toString());
			currentState = action.execute(currentState);
			if(problemB.goalTest(currentState)) break;
			
			System.out.println("TurnB");
			problemB.experimentingUtility(currentState, true);
			System.out.println(currentState.toString());
			
		}
		scanner.close();
		
		System.out.println("Solved:");
		System.out.println(currentState.toString());
	}
	
	public static void analyseAIs(){
		int[][][][] winner = new int[2][2][7][7];
		
		for(int da = 0; da < winner.length; da++){
			for(int db = 0; db < winner[da].length; db++){
				for(int dea = 0; dea < winner[da][db].length; dea++){
					for(int deb = 0; deb < winner[da][db][dea].length; deb++){
						winner[da][db][dea][deb] = aiVsAi(da, db, dea, deb);
					}
				}
			}
		}
		
		//Print result
		System.out.print("da+db\t");
		for(int dea = 0; dea < 20; dea++){
			for(int deb = 0; deb < 20; deb++){
				System.out.print(dea+"+"+deb+"\t");
			}
		}
		System.out.print("\n");
		for(int da = 0; da < winner.length; da++){
			for(int db = 0; db < winner[da].length; db++){
				System.out.print(da+"+"+db+"\t");
				for(int dea = 0; dea < winner[da][db].length; dea++){
					for(int deb = 0; deb < winner[da][db][dea].length; deb++){
						System.out.print(winner[da][db][dea][deb]+"\t");
					}
				}
				System.out.print("\n");
			}
		}
	}
	
	/**
	 * PlayerA always begins.
	 * @param difficultyA
	 * @param difficultyB
	 * @param maxDepthA
	 * @param maxDepthB
	 * @return 0 if A wins, 1 if b wins, 3 if draw.
	 */
	public static int aiVsAi(int difficultyA, int difficultyB, int maxDepthA, int maxDepthB){
		ConnectFourProblem problemA = new ConnectFourProblem(ConnectFourState.FieldState.RED, difficultyA);
		AlphaBetaSearch playerA = new AlphaBetaSearch(problemA, maxDepthA);
		
		ConnectFourProblem problemB = new ConnectFourProblem(ConnectFourState.FieldState.YELLOW , difficultyB);
		AlphaBetaSearch playerB = new AlphaBetaSearch(problemB, maxDepthB);
		
		ConnectFourState currentState = (ConnectFourState) problemA.getInitialState();

		Action action;
		
		boolean running = true;
		
		int i = 0;
		while(running){
			System.out.println("Step: "+i);
			//System.out.println("Current State: ");
			//long startTime = System.currentTimeMillis();

			//PlayerA turn
			action = playerA.search(currentState);
			currentState = (ConnectFourState) action.execute(currentState);
			if(problemA.goalTest(currentState)){
				System.out.println("A Wins!");
				System.out.println(currentState.toString());
				return 0;
			}
			//System.out.println("TurnA");
			problemB.experimentingUtility(currentState, true);
			System.out.println(currentState.toString());
			//PlayerB turn
			action = playerB.search(currentState);
			currentState = (ConnectFourState) action.execute(currentState);
			if(problemB.goalTest(currentState)){
				System.out.println("B Wins!");
				System.out.println(currentState.toString());
				return 1;
			}
			//System.out.println("TurnB");
			problemB.experimentingUtility(currentState, true);
			System.out.println(currentState.toString());
			
			//Check if the field is full
			boolean foundEmpty = false;
			for(int column = 0; column < 7; column++){
				for(int row = 0; row < 6; row++){
					if(currentState.grid[column][row] == ConnectFourState.FieldState.EMPTY){
						foundEmpty = true;
						break;
					}
				}
			}
			if(!foundEmpty) running = false;
			i++;
		}
		
		System.out.println("Draw");
		return 3;
		
		//System.out.println("Solved:");
		
	}

}
