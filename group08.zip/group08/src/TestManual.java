import java.util.ArrayList;

import genericSearchProblem.Action;
import genericSearchProblem.State;


public class TestManual {

	public static void main(String[] args) {
		ConnectFourProblem p = new ConnectFourProblem(ConnectFourState.FieldState.RED,4);
		//AlphaBetaSearch playerA = new AlphaBetaSearch(problemA);
		State s = p.getInitialState();
		System.out.println();
		ArrayList<Action> actions = p.getActions(s);
		
		//Test horizontal left and right
		//int actionsX[] = {1,2,3,4,1};
		//int actionsO[] = {2,3,5,4,3};
		int actionsX[] = {3,2,1};
		int actionsO[] = {3,2,1};
		playActions(actionsX, actionsO);

		
		/*
		State s1 = actions.get(2).execute(s);
		System.out.println(s1.toString());
		System.out.println("Utility: "+p.utility(s1)+" Goal: "+p.goalTest(s1));
		s1 = actions.get(6).execute(s1);
		System.out.println(s1.toString());
		System.out.println("Utility: "+p.utility(s1)+" Goal: "+p.goalTest(s1));
		s1 = actions.get(2).execute(s1);
		System.out.println(s1.toString());
		System.out.println("Utility: "+p.utility(s1)+" Goal: "+p.goalTest(s1));
		s1 = actions.get(6).execute(s1);
		System.out.println(s1.toString());
		System.out.println("Utility: "+p.utility(s1)+" Goal: "+p.goalTest(s1));
		s1 = actions.get(2).execute(s1);
		System.out.println(s1.toString());
		System.out.println("Utility: "+p.utility(s1)+" Goal: "+p.goalTest(s1));
		s1 = actions.get(6).execute(s1);
		System.out.println(s1.toString());
		System.out.println("Utility: "+p.utility(s1)+" Goal: "+p.goalTest(s1));
		*/

	}
	
	private static void playActions(int[] actionsX, int[] actionsO){
		if(actionsX.length != actionsO.length) return;
		
		ConnectFourProblem p = new ConnectFourProblem(ConnectFourState.FieldState.RED,4);
		State s = p.getInitialState();
		ArrayList<Action> actions = p.getActions(s);
		
		for(int i = 0; i < actionsX.length; i++){
			s = actions.get(actionsX[i]).execute(s);
			s = actions.get(actionsO[i]).execute(s);
			
			System.out.println("==================");
			System.out.println("Utility: "+p.experimentingUtility(s, true)+" Goal: "+p.goalTest(s));
			System.out.println(s.toString());
		}
		
	}
	

}
