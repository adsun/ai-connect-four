package genericSearchProblem;

import java.util.ArrayList;

public class Node {
	
	/**
	 * State in the state space to which the node corresponds.
	 */
	private State state;
	
	/**
	 * Node in the tree that generated this node.
	 */
	private Node parent;
	
	/**
	 * Action applied to parent to generate this node.
	 */
	private Action action;
	
	/**
	 * Cost from the initial state to this node.
	 */
	private double pathCost;
	
	public Node(State state, double pathCost){
		this.state = state;
		this.pathCost = pathCost;
	}

	/**
	 * Class constructor.
	 * @param state
	 * @param parent
	 * @param action
	 * @param pathCost
	 */
	public Node(State state, Node parent, Action action, double pathCost){
		this.state = state;
		this.parent = parent;
		this.action = action;
		this.pathCost = pathCost;
	}
	
	/**
	 * Performs the action on this node, checks if the state is valid and returns the resulting node.
	 * @param problem
	 * @param action
	 * @return new node or null if state is invalid
	 */
	public Node getChildNode(Problem problem,  Action action){
		State childState = problem.performAction(action, state);
		if(childState != null){
			return new Node(childState, this, action, pathCost+problem.getStepCost(this.state, action));
		}
		return null;
	}


	public State getState() {
		return state;
	}

	/**
	 * 
	 * @return List of all nodes visited to get to this node.
	 */
	public ArrayList<Node> getSolution() {
		ArrayList<Node> solution = new ArrayList<Node>();
		if(parent != null){
			solution.addAll(parent.getSolution());
		}
		solution.add(this);
		return solution;
	}
	
	@Override
	public String toString(){
		if(parent != null){
			return pathCost + "\t| "+ "From "+parent.state.toString() +" to "+state.toString()+"| " +action.toString();
		}
		return pathCost + "\t| "+ "Starting at "+state.toString(); 
		
	}
	
	@Override
	public boolean equals(Object o){
		if(!(o instanceof Node)) return false;
		Node other = (Node) o;
		
		//TODO add other cases
		if(!state.equals(other.state)) return false;
		
		return true;
		
	}
	
}
