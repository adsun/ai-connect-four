import java.util.ArrayList;
import java.util.Arrays;

import genericSearchProblem.Action;
import genericSearchProblem.Problem;
import genericSearchProblem.State;


public class ConnectFourProblem extends Problem{
	
	public static final int EASY = 0;
	public static final int ADVANCED = 1;
	public static final int EXPERT = 2;
	public static final int EXPERIMENTAL = 3;
	
	int difficulty;
	
	public ArrayList<Action> actions;
	
	private ConnectFourState.FieldState player;
	
	
	
	
	public ConnectFourProblem(ConnectFourState.FieldState player, int difficulty) {
		actions = new ArrayList<Action>();
		initActions();
		this.player = player;
		this.difficulty = difficulty;
	}
	

	@Override
	public State getInitialState() {
		//Initialize empty board with 7 columns and 6 rows
		ConnectFourState.FieldState[][] grid = new ConnectFourState.FieldState[7][6];
		
		for(int column = 0; column < 7; column++){
			for(int row = 0; row < 6; row++){
				grid[column][row] = ConnectFourState.FieldState.EMPTY;
			}
		}
		//grid[3][0] = ConnectFourState.FieldState.RED;
		if(player == ConnectFourState.FieldState.RED){
			return new ConnectFourState(grid, ConnectFourState.FieldState.YELLOW);
		}else{
			return new ConnectFourState(grid, ConnectFourState.FieldState.RED);
		}
		
	}

	@Override
	public boolean goalTest(State state) {
		if(!(state instanceof ConnectFourState)) return false;
		ConnectFourState s = (ConnectFourState) state;
		ConnectFourState.FieldState[][] grid = s.grid;
		
		//Check every field
		for(int column = 0; column < 7; column++){
			for(int row = 0; row < 6; row++){
				ConnectFourState.FieldState field = grid[column][row];
				
				if(field != ConnectFourState.FieldState.EMPTY){
					//Assume field is the bottom left slot of four in a row.
					
					//Check four above
					if(row <= 2){
						boolean goal = true;
						for(int i = row+1; i < row+4; i++){
							if(grid[column][i] != field){
								goal = false;
								break;
							}
						}
						
						if(goal) return true;
					}
					
					//Check to the right
					if(column <= 3){
						boolean goal = true;
						for(int i = column+1; i < column+4; i++){
							if(grid[i][row] != field){
								goal = false;
								break;
							}
						}
						
						if(goal) return true;
					}
					
					//Check diagonal up
					if(row <= 2 && column <= 3){
						boolean goal = true;
						for(int i = 1; i < 4; i++){
							if(grid[column+i][row+i] != field){
								goal = false;
								break;
							}
						}
						
						if(goal) return true;
					}
					
					//Check diagonal down
					if(row > 2 && column <= 3){
						boolean goal = true;
						for(int i = 1; i < 4; i++){
							if(grid[column+i][row-i] != field){
								goal = false;
								break;
							}
						}
						
						if(goal) return true;
					}
					
				}
			}	
		}
		
		return false;
	}
	

	@Override
	public ArrayList<Action> getActions(State state) {
		if(!(state instanceof ConnectFourState)) return null;
		ConnectFourState s = (ConnectFourState) state;
		
		ArrayList<Action> result = new ArrayList<Action>();
		
		for(int i = 0; i < 7; i++){
			
			if(s.grid[i][5] == ConnectFourState.FieldState.EMPTY){
				result.add(actions.get(i));
			}
		}
		return result;
	}

	@Override
	public double getStepCost(State state, Action action) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public double utility(State state){
		switch(difficulty){
			case EASY:
				return easyUtility(state);
			case ADVANCED:
				return advancedUtility(state);
			case EXPERT:
				return expertUtility2(state);
			case EXPERIMENTAL:
				return experimentingUtility(state, false);
			default:
				return experimentingUtility(state,true);
		}
	}
	
	public double experimentingUtility(State state, boolean log){
		if(!(state instanceof ConnectFourState)) return Double.MAX_VALUE;
		ConnectFourState s = (ConnectFourState) state;
		
		ConnectFourState.FieldState player = s.turn;
		ConnectFourState.FieldState opponent;
		if(player == ConnectFourState.FieldState.RED){
			opponent = ConnectFourState.FieldState.YELLOW;
		}else{
			opponent = ConnectFourState.FieldState.RED;
		}
		
		//Features: {4,3,3,3,3,2,1
		double features[] = new double[7];
		double weights[] =  {1,1,1,1,1,1,1};
		int attacks[] = new int[7];
		int threats[] = new int[7];
		double attackWeights[] = {1,1,1,1,1,1,1};
		double threatWeights[] = {1.1,1.1,1.1,1.1,1.1,1.1,1.1};
		//Iterate over all fields.
		//Count each kind of threat for the empty fields.
		ConnectFourState.FieldState color;
		for(int column = 0; column < 7; column++){
			for(int row = 0; row < 6; row++){
				
				
				/*
				 * Counting feature 0:
				 * Four in a rows. We count attacks and threats.
				 * Always assume we are in the top left field of the four.
				 */
				if(s.grid[column][row] != ConnectFourState.FieldState.EMPTY){
					color = s.grid[column][row];
					
					//Check three to the right
					if( column < 4 &&
						s.grid[column+1][row] == color &&
						s.grid[column+2][row] == color &&
						s.grid[column+3][row] == color){
						//Found 4 in a row
						if(color == player) attacks[0]++;
						else if(color == opponent) threats[0]++;
					}
					
					//Check three below, straight down, diagonal left and right
					if(row > 2){
						//Down
						if(	s.grid[column][row-1] == color &&
							s.grid[column][row-2] == color &&
							s.grid[column][row-3] == color){
							//Found 4 in a row
							if(color == player) attacks[0]++;
							else if(color == opponent) threats[0]++;
						}
					
						//Down and left
						if( column > 2 &&
							s.grid[column-1][row-1] == color &&
							s.grid[column-2][row-2] == color &&
							s.grid[column-3][row-3] == color){
							//Found 4 in a row
							if(color == player) attacks[0]++;
							else if(color == opponent) threats[0]++;
						}
						
						//Down and right
						//Check three to the right
						if( column < 4 &&
							s.grid[column+1][row-1] == color &&
							s.grid[column+2][row-2] == color &&
							s.grid[column+3][row-3] == color){
							//Found 4 in a row
							if(color == player) attacks[0]++;
							else if(color == opponent) threats[0]++;
						}
					}
				}//End of feature 0
				
				features[0] = attackWeights[0]*attacks[0] - threatWeights[0]*threats[0];
				
				/*
				 * Counting feature 1 and feature 2:
				 * Three in a rows, which can be turned into a four in a row
				 * with one stone. We look for empty fields, check if there is
				 * something below it and look in any of the 7 directions if there
				 * are three times the same color.
				 * If it is the player color, we increase attacks[0], threats[0] if
				 * it is the opponents color.
				 * Feature 2 is the same but the stone below is empty
				 */
				if(s.grid[column][row] == ConnectFourState.FieldState.EMPTY){
					//Three in a rows and a stone below
					
					//Three below
					if(row > 2){
						//Decide if potential attack or threat
						color = s.grid[column][row-1];
					
						if( s.grid[column][row-2] == color &&
							s.grid[column][row-3] == color){
							//Found 3 in a row
							if(color == player) attacks[1]++;
							else if(color == opponent) threats[1]++;
						}
					}
					
					//Three diagonal left down
					if(column > 2 && row > 2){
						//Decide if potential attack or threat
						color = s.grid[column-1][row-1];
					
						if( s.grid[column-2][row-2] == color &&
							s.grid[column-3][row-3] == color){
							//Found 3 in a row
							if(s.grid[column][row-1] != ConnectFourState.FieldState.EMPTY){
								if(color == player) attacks[1]++;
								else if(color == opponent) threats[1]++;
							}else{
								if(color == player) attacks[2]++;
								else if(color == opponent) threats[2]++;
							}
							
						}
					}
					
					//Three diagonal right down
					if(column < 4 && row > 2){
						//Decide if potential attack or threat
						color = s.grid[column+1][row-1];
					
						if( s.grid[column+2][row-2] == color &&
							s.grid[column+3][row-3] == color){
							//Found 3 in a row
							if(s.grid[column][row-1] != ConnectFourState.FieldState.EMPTY){
								if(color == player) attacks[1]++;
								else if(color == opponent) threats[1]++;
							}else{
								if(color == player) attacks[2]++;
								else if(color == opponent) threats[2]++;
							}
						}
					}
					
					//Three diagonal left up and NOT on the ground
					if(column > 2 && row < 3 && row > 0){
						//Decide if potential attack or threat
						color = s.grid[column-1][row+1];
					
						if( s.grid[column-2][row+2] == color &&
							s.grid[column-3][row+3] == color){
							//Found 3 in a row
							if(s.grid[column][row-1] != ConnectFourState.FieldState.EMPTY){
								if(color == player) attacks[1]++;
								else if(color == opponent) threats[1]++;
							}else{
								if(color == player) attacks[2]++;
								else if(color == opponent) threats[2]++;
							}
						}
					}
					
					//Three diagonal right up and NOT on the ground
					if(column < 4 && row < 3 && row > 0){
						//Decide if potential attack or threat
						color = s.grid[column+1][row+1];
					
						if( s.grid[column+2][row+2] == color &&
							s.grid[column+3][row+3] == color){
							//Found 3 in a row
							if(s.grid[column][row-1] != ConnectFourState.FieldState.EMPTY){
								if(color == player) attacks[1]++;
								else if(color == opponent) threats[1]++;
							}else{
								if(color == player) attacks[2]++;
								else if(color == opponent) threats[2]++;
							}
						}
					}
					
					//Three diagonal left up and on the ground
					if(column > 2 && row < 3 && row == 0){
						//Decide if potential attack or threat
						color = s.grid[column-1][row+1];
					
						if( s.grid[column-2][row+2] == color &&
							s.grid[column-3][row+3] == color){
							//Found 3 in a row
							if(color == player) attacks[1]++;
							else if(color == opponent) threats[1]++;
						}
					}
					
					//Three diagonal right up and on the ground
					if(column < 4 && row < 3 && row == 0){
						//Decide if potential attack or threat
						color = s.grid[column+1][row+1];
					
						if( s.grid[column+2][row+2] == color &&
							s.grid[column+3][row+3] == color){
							//Found 3 in a row
							if(color == player) attacks[1]++;
							else if(color == opponent) threats[1]++;
						}
					}
					
					
					//Three horizontal left and NOT on the ground
					if(column > 2 && row > 0){
						//Decide if potential attack or threat
						color = s.grid[column-1][row];
					
						if( s.grid[column-2][row] == color &&
							s.grid[column-3][row] == color){
							//Found 3 in a row
							if(s.grid[column][row-1] != ConnectFourState.FieldState.EMPTY){
								if(color == player) attacks[1]++;
								else if(color == opponent) threats[1]++;
							}else{
								if(color == player) attacks[2]++;
								else if(color == opponent) threats[2]++;
							}
						}
					}
					
					//Three horizontal right and NOT on the ground
					if(column < 4 && row > 0){
						//Decide if potential attack or threat
						color = s.grid[column+1][row];
					
						if( s.grid[column+2][row] == color &&
							s.grid[column+3][row] == color){
							//Found 3 in a row
							if(s.grid[column][row-1] != ConnectFourState.FieldState.EMPTY){
								if(color == player) attacks[1]++;
								else if(color == opponent) threats[1]++;
							}else{
								if(color == player) attacks[2]++;
								else if(color == opponent) threats[2]++;
							}
						}
					}
					
					//Three horizontal left and on the ground
					if(column > 2 && row == 0){
						//Decide if potential attack or threat
						color = s.grid[column-1][row];
					
						if(	s.grid[column-2][row] == color &&
							s.grid[column-3][row] == color){
							//Found 3 in a row
							if(color == player) attacks[1]++;
							else if(color == opponent) threats[1]++;
						}
					}
					
					//Three horizontal right and on the ground
					if(column < 4 && row == 0){
						//Decide if potential attack or threat
						color = s.grid[column+1][row];
					
						if(	s.grid[column+2][row] == color &&
							s.grid[column+3][row] == color){
							//Found 3 in a row
							if(color == player) attacks[1]++;
							else if(color == opponent) threats[1]++;
						}
					}
				}//End of feature 1 and 2
				
				features[1] = attackWeights[1]*attacks[1] - threatWeights[1]*threats[1];
				features[2] = attackWeights[2]*attacks[2] - threatWeights[2]*threats[2];
				
				/*
				 * Counting feature 3 and 4: XX_X X_XX
				 * Three is with piece below, four without
				 */
				if(s.grid[column][row] == ConnectFourState.FieldState.EMPTY){
					
					//Check Horizontal

					//XX_X
					if(column > 1 && column < 6){
						//Decide if potential attack or threat
						color = s.grid[column+1][row];
					
						if(	color != ConnectFourState.FieldState.EMPTY &&
							s.grid[column-1][row] == color &&
							s.grid[column-2][row] == color){
							//Found 3 in a row
							if(row == 0 || s.grid[column][row-1] != ConnectFourState.FieldState.EMPTY){
								if(color == player) attacks[3]++;
								else if(color == opponent) threats[3]++;
							}else{
								if(color == player) attacks[4]++;
								else if(color == opponent) threats[4]++;
							}
							
						}
					}
					
					//X_XX
					if(column > 0 && column < 5){
						//Decide if potential attack or threat
						color = s.grid[column-1][row];
					
						if(	color != ConnectFourState.FieldState.EMPTY &&
							s.grid[column+1][row] == color &&
							s.grid[column+2][row] == color){
							//Found 3 in a row
							if(row == 0 || s.grid[column][row-1] != ConnectFourState.FieldState.EMPTY){
								if(color == player) attacks[3]++;
								else if(color == opponent) threats[3]++;
							}else{
								if(color == player) attacks[4]++;
								else if(color == opponent) threats[4]++;
							}
						}
					}
					
					
					/*
					 * Check diagonal
					 * X
					 *  _
					 *   X
					 *    X
					 */
					if(column > 0 && column < 5 && row > 1 && row < 5){
						//Decide if potential attack or threat
						color = s.grid[column-1][row+1];
					
						if(	color != ConnectFourState.FieldState.EMPTY &&
							s.grid[column+1][row-1] == color &&
							s.grid[column+2][row-2] == color){
							//Found 3 in a row
							if(s.grid[column][row-1] != ConnectFourState.FieldState.EMPTY){
								if(color == player) attacks[3]++;
								else if(color == opponent) threats[3]++;
							}else{
								if(color == player) attacks[4]++;
								else if(color == opponent) threats[4]++;
							}
						}
					}
					
					/*
					 * Check diagonal
					 * X
					 *  X
					 *   _
					 *    X
					 */
					if(column > 1 && column < 6 && row > 0 && row < 4){
						//Decide if potential attack or threat
						color = s.grid[column+1][row-1];
					
						if(	color != ConnectFourState.FieldState.EMPTY &&
							s.grid[column-1][row+1] == color &&
							s.grid[column-2][row+2] == color){
							//Found 3 in a row
							if(s.grid[column][row-1] != ConnectFourState.FieldState.EMPTY){
								if(color == player) attacks[3]++;
								else if(color == opponent) threats[3]++;
							}else{
								if(color == player) attacks[4]++;
								else if(color == opponent) threats[4]++;
							}
						}
					}
					
					/*
					 * Check diagonal
					 *    X
					 *   _
					 *  X
					 * X
					 */
					if(column > 1 && column < 6 && row > 1 && row < 5){
						//Decide if potential attack or threat
						color = s.grid[column+1][row+1];
					
						if(	color != ConnectFourState.FieldState.EMPTY &&
							s.grid[column-1][row-1] == color &&
							s.grid[column-2][row-2] == color){
							//Found 3 in a row
							if(s.grid[column][row-1] != ConnectFourState.FieldState.EMPTY){
								if(color == player) attacks[3]++;
								else if(color == opponent) threats[3]++;
							}else{
								if(color == player) attacks[4]++;
								else if(color == opponent) threats[4]++;
							}
						}
					}
					
					/*
					 * Check diagonal
					 *    X
					 *   X
					 *  _
					 * X
					 */
					if(column > 0 && column < 5 && row > 0 && row < 4){
						//Decide if potential attack or threat
						color = s.grid[column-1][row-1];
					
						if(	color != ConnectFourState.FieldState.EMPTY &&
							s.grid[column+1][row+1] == color &&
							s.grid[column+2][row+2] == color){
							//Found 3 in a row
							if(s.grid[column][row-1] != ConnectFourState.FieldState.EMPTY){
								if(color == player) attacks[3]++;
								else if(color == opponent) threats[3]++;
							}else{
								if(color == player) attacks[4]++;
								else if(color == opponent) threats[4]++;
							}
						}
					}
					
				}//End Feature 2
				
				features[3] = attackWeights[3]*attacks[3] - threatWeights[3]*threats[3];
				features[4] = attackWeights[4]*attacks[4] - threatWeights[4]*threats[4];
				
				/*
				 * Feature 5 and6: 2 in 4 which are not blocked and 1 in 4 which are not blocked
				 * Not as precise approach as before.
				 */
				
				//Check above X X _ _
				if(row < 3){
					color = s.grid[column][row];
					if( color != ConnectFourState.FieldState.EMPTY &&
						s.grid[column][row+1] == color &&
						s.grid[column][row+2] == ConnectFourState.FieldState.EMPTY &&
						s.grid[column][row+3] == ConnectFourState.FieldState.EMPTY){
	
						if(color == player) attacks[5]++;
						else if(color == opponent) threats[5]++;
					}
				}
				
				//Check above x _ _ _
				if(row < 3){
					color = s.grid[column][row];
					if( color != ConnectFourState.FieldState.EMPTY &&
						s.grid[column][row+1] == ConnectFourState.FieldState.EMPTY &&
						s.grid[column][row+2] == ConnectFourState.FieldState.EMPTY &&
						s.grid[column][row+3] == ConnectFourState.FieldState.EMPTY){
	
						if(color == player) attacks[6]++;
						else if(color == opponent) threats[6]++;
					}
				}
				
				
				//Check to the right
				if(column <= 3){
					int count = 0;
					
					color = null;
					boolean notOccupied = true;
					for(int i = 0; i < 4; i++){
						if(s.grid[column+i][row] != ConnectFourState.FieldState.EMPTY){
							color = s.grid[column+i][row];
						}
						if(color != null && s.grid[column+i][row] == color){
							count++;
						}else if(s.grid[column+i][row] == ConnectFourState.FieldState.EMPTY){
							
						}else{
							notOccupied = false;
							break;
						}
					}
					
					if(notOccupied){
						if(count == 2){
							if(color == player) attacks[5]++;
							else if(color == opponent) threats[5]++;
						}else if( count == 1){
							if(color == player) attacks[6]++;
							else if(color == opponent) threats[6]++;
						}
					}
				}
				
				
				//Check diagonal top right
				if(column < 4 && row < 3){
					int count = 0;
					
					color = null;
					boolean notOccupied = true;
					for(int i = 0; i < 4; i++){
						if(s.grid[column+i][row] != ConnectFourState.FieldState.EMPTY){
							color = s.grid[column+i][row+i];
						}
						if(color != null && s.grid[column+i][row+i] == color){
							count++;
						}else if(s.grid[column+i][row+i] == ConnectFourState.FieldState.EMPTY){
							
						}else{
							notOccupied = false;
							break;
						}
					}
					
					if(notOccupied){
						if(count == 2){
							if(color == player) attacks[5]++;
							else if(color == opponent) threats[5]++;
						}else if( count == 1){
							if(color == player) attacks[6]++;
							else if(color == opponent) threats[6]++;
						}
					}
				}
				
				//Check diagonal bottom right
				if(column < 4 && row > 2){
					int count = 0;
					
					color = null;
					boolean notOccupied = true;
					for(int i = 0; i < 4; i++){
						if(s.grid[column+i][row] != ConnectFourState.FieldState.EMPTY){
							color = s.grid[column+i][row-i];
						}
						if(color != null && s.grid[column+i][row-i] == color){
							count++;
						}else if(s.grid[column+i][row-i] == ConnectFourState.FieldState.EMPTY){
							
						}else{
							notOccupied = false;
							break;
						}
					}
					
					if(notOccupied){
						if(count == 2){
							if(color == player) attacks[5]++;
							else if(color == opponent) threats[5]++;
						}else if( count == 1){
							if(color == player) attacks[6]++;
							else if(color == opponent) threats[6]++;
						}
					}
				}
				
				
				features[5] = attackWeights[5]*attacks[5] - threatWeights[5]*threats[5];
				features[6] = attackWeights[6]*attacks[6] - threatWeights[6]*threats[6];
				
			}
		}
				
		double result = 500;
		for(int i = 0; i < features.length; i++){
			result += weights[i]*features[i];
		}
		if(log){
			System.out.println("Attacks:\t"+Arrays.toString(attacks));
			System.out.println("Threats:\t"+Arrays.toString(threats));
			System.out.println("Features:\t"+Arrays.toString(features));
			System.out.println("Utility:\t"+result);
		}
		return result;
	}
	
	public static double expertUtility2(State state){
		if(!(state instanceof ConnectFourState)) return Double.MAX_VALUE;
		ConnectFourState s = (ConnectFourState) state;
		
		//{empty fours, ones, twos, threes, fours}
		int[] counts = new int[5];
		double[] weights =  {.0,.2,10,1000,10000000.0};
		
		ConnectFourState.FieldState player = s.turn;
		ConnectFourState.FieldState opponent;
		if(player == ConnectFourState.FieldState.RED){
			opponent = ConnectFourState.FieldState.YELLOW;
		}else{
			opponent = ConnectFourState.FieldState.RED;
		}
		
		//Check every field
		for(int column = 0; column < 7; column++){
			for(int row = 0; row < 6; row++){
				ConnectFourState.FieldState field = s.grid[column][row];
				
				
				
				if(field == ConnectFourState.FieldState.EMPTY || field == s.turn){
					int count = 0;
					//Check four above
					if(row <= 2){
						boolean notOccupied = true;
						for(int i = row; i < row+4; i++){
							if(s.grid[column][i] == opponent){
								notOccupied = false;
								break;
							}else if(s.grid[column][i] == s.turn){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
					count = 0;
					//Check to the right
					if(column <= 3){
						boolean notOccupied = true;
						for(int i = column; i < column+4; i++){
							if(s.grid[i][row] == opponent){
								notOccupied = false;
								break;
							}else if(s.grid[i][row] == s.turn){
								count++;
							}
							
						}
						
						if(notOccupied) counts[count]++;
					}
					count = 0;
					//Check diagonal up
					if(row <= 2 && column <= 3){
						boolean notOccupied = true;
						for(int i = 0; i < 4; i++){
							if(s.grid[column+i][row+i] == opponent){
								notOccupied = false;
								break;
							}else if(s.grid[column+i][row+i] == s.turn){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
					count = 0;
					//Check diagonal down
					if(row > 2 && column <= 3){
						boolean notOccupied = true;
						for(int i = 0; i < 4; i++){
							if(s.grid[column+i][row-i] == opponent){
								notOccupied = false;
								break;
							}else if(s.grid[column+i][row-i] == s.turn){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
				}
			}	
		}
			
		double value1 = 0;
		
		for(int i = 0; i < counts.length; i++){
			value1 += weights[i]*counts[i];
		} 
		//System.out.println("Value: "+ value1);
		//System.out.println("Counts: "+Arrays.toString(counts));
		//System.out.println("Value: "+ value+" "+"Counts:"+Arrays.toString(counts));
		//System.out.println(s.toString());
		
		
		counts = new int[5];
		
		//Check every field AGAIN
		for(int column = 0; column < 7; column++){
			for(int row = 0; row < 6; row++){
				ConnectFourState.FieldState field = s.grid[column][row];
				
				
				
				if(field == ConnectFourState.FieldState.EMPTY || field == opponent){
					int count = 0;
					//Check four above
					if(row <= 2){
						boolean notOccupied = true;
						for(int i = row; i < row+4; i++){
							if(s.grid[column][i] == s.turn){
								notOccupied = false;
								break;
							}else if(s.grid[column][i] == opponent){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
					count = 0;
					//Check to the right
					if(column <= 3){
						boolean notOccupied = true;
						for(int i = column; i < column+4; i++){
							if(s.grid[i][row] == s.turn){
								notOccupied = false;
								break;
							}else if(s.grid[i][row] == opponent){
								count++;
							}
							
						}
						
						if(notOccupied) counts[count]++;
					}
					count = 0;
					//Check diagonal up
					if(row <= 2 && column <= 3){
						boolean notOccupied = true;
						for(int i = 0; i < 4; i++){
							if(s.grid[column+i][row+i] == s.turn){
								notOccupied = false;
								break;
							}else if(s.grid[column+i][row+i] == opponent){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
					count = 0;
					//Check diagonal down
					if(row > 2 && column <= 3){
						boolean notOccupied = true;
						for(int i = 0; i < 4; i++){
							if(s.grid[column+i][row-i] == s.turn){
								notOccupied = false;
								break;
							}else if(s.grid[column+i][row-i] == opponent){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
				}
			}	
		}
		
		double value2=0;
		for(int i = 0; i < counts.length; i++){
			value2 += weights[i]*counts[i];
		} 
		//System.out.println("Value2: "+ value2);
		//System.out.println("Counts: "+Arrays.toString(counts));
		//System.out.println(s.toString());
		
		return value1-(3*value2);
	}
	//TODO
	public double expertUtility(State state){
		if(!(state instanceof ConnectFourState)) return Double.MAX_VALUE;
		ConnectFourState s = (ConnectFourState) state;
		
		//{empty fours, ones, twos, threes, fours}
		int[] counts = new int[5];
		double[] weights =  {.0,.7,10,100,1000.0};
		
		ConnectFourState.FieldState opponent;
		if(s.turn == ConnectFourState.FieldState.RED){
			opponent = ConnectFourState.FieldState.YELLOW;
		}else{
			opponent = ConnectFourState.FieldState.RED;
		}
		
		//Check every field
		for(int column = 0; column < 7; column++){
			for(int row = 0; row < 6; row++){
				ConnectFourState.FieldState field = s.grid[column][row];
				
				
				
				if(field == ConnectFourState.FieldState.EMPTY || field == s.turn){
					int count = 0;
					//Check four above
					if(row <= 2){
						boolean notOccupied = true;
						for(int i = row; i < row+4; i++){
							if(s.grid[column][i] == opponent){
								notOccupied = false;
								break;
							}else if(s.grid[column][i] == s.turn){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
					count = 0;
					//Check to the right
					if(column <= 3){
						boolean notOccupied = true;
						for(int i = column; i < column+4; i++){
							if(s.grid[i][row] == opponent){
								notOccupied = false;
								break;
							}else if(s.grid[i][row] == s.turn){
								count++;
							}
							
						}
						
						if(notOccupied) counts[count]++;
					}
					count = 0;
					//Check diagonal up
					if(row <= 2 && column <= 3){
						boolean notOccupied = true;
						for(int i = 0; i < 4; i++){
							if(s.grid[column+i][row+i] == opponent){
								notOccupied = false;
								break;
							}else if(s.grid[column+i][row+i] == s.turn){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
					count = 0;
					//Check diagonal down
					if(row > 2 && column <= 3){
						boolean notOccupied = true;
						for(int i = 0; i < 4; i++){
							if(s.grid[column+i][row-i] == opponent){
								notOccupied = false;
								break;
							}else if(s.grid[column+i][row-i] == s.turn){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
				}
			}	
		}
			
		double value1 = 0;
		
		for(int i = 0; i < counts.length; i++){
			value1 += weights[i]*counts[i];
		} 
		System.out.println("Value: "+ value1);
		System.out.println("Counts: "+Arrays.toString(counts));
		//System.out.println("Value: "+ value+" "+"Counts:"+Arrays.toString(counts));
		//System.out.println(s.toString());
		
		counts = new int[5];
		
		//Check every field AGAIN
		for(int column = 0; column < 7; column++){
			for(int row = 0; row < 6; row++){
				ConnectFourState.FieldState field = s.grid[column][row];
				
				
				
				if(field == ConnectFourState.FieldState.EMPTY || field == opponent){
					int count = 0;
					//Check four above
					if(row <= 2){
						boolean notOccupied = true;
						for(int i = row; i < row+4; i++){
							if(s.grid[column][i] == s.turn){
								notOccupied = false;
								break;
							}else if(s.grid[column][i] == opponent){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
					count = 0;
					//Check to the right
					if(column <= 3){
						boolean notOccupied = true;
						for(int i = column; i < column+4; i++){
							if(s.grid[i][row] == s.turn){
								notOccupied = false;
								break;
							}else if(s.grid[i][row] == opponent){
								count++;
							}
							
						}
						
						if(notOccupied) counts[count]++;
					}
					count = 0;
					//Check diagonal up
					if(row <= 2 && column <= 3){
						boolean notOccupied = true;
						for(int i = 0; i < 4; i++){
							if(s.grid[column+i][row+i] == s.turn){
								notOccupied = false;
								break;
							}else if(s.grid[column+i][row+i] == opponent){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
					count = 0;
					//Check diagonal down
					if(row > 2 && column <= 3){
						boolean notOccupied = true;
						for(int i = 0; i < 4; i++){
							if(s.grid[column+i][row-i] == s.turn){
								notOccupied = false;
								break;
							}else if(s.grid[column+i][row-i] == opponent){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
				}
			}	
		}
		
		double value2=0;
		for(int i = 0; i < counts.length; i++){
			value2 += weights[i]*counts[i];
		} 
		System.out.println("Value2: "+ value2);
		System.out.println("Counts: "+Arrays.toString(counts));
		System.out.println(s.toString());
		
		return value1-value2;
		
	}
	
	/**
	 * Second attempt at a utility function.
	 * Counts the ammount of 0 in a rows, two in a rows, three in a rows and four in a rows,
	 * which are not blocked by the enemy and thus still expandable to a four in a row.
	 * Each of these counts has a weight assigned to it.
	 * TODO Adjust weights.
	 * @param state
	 * @return
	 */
	public double advancedUtility(State state){
		if(!(state instanceof ConnectFourState)) return Double.MAX_VALUE;
		ConnectFourState s = (ConnectFourState) state;
		
		//{empty fours, ones, twos, threes, fours}
		int[] counts = new int[5];
		//double[] weights =  {.0,.7,.9,10.0,20.0};
		double[] weights =  {.0,.7,10,100,1000.0};
		
		ConnectFourState.FieldState opponent;
		if(s.turn == ConnectFourState.FieldState.RED){
			opponent = ConnectFourState.FieldState.YELLOW;
		}else{
			opponent = ConnectFourState.FieldState.RED;
		}
		
		//Check every field
		for(int column = 0; column < 7; column++){
			for(int row = 0; row < 6; row++){
				ConnectFourState.FieldState field = s.grid[column][row];
				
				
				
				if(field == ConnectFourState.FieldState.EMPTY || field == s.turn){
					int count = 0;
					//Check four above
					if(row <= 2){
						boolean notOccupied = true;
						for(int i = row; i < row+4; i++){
							if(s.grid[column][i] == opponent){
								notOccupied = false;
								break;
							}else if(s.grid[column][i] == s.turn){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
					count = 0;
					//Check to the right
					if(column <= 3){
						boolean notOccupied = true;
						for(int i = column; i < column+4; i++){
							if(s.grid[i][row] == opponent){
								notOccupied = false;
								break;
							}else if(s.grid[i][row] == s.turn){
								count++;
							}
							
						}
						
						if(notOccupied) counts[count]++;
					}
					count = 0;
					//Check diagonal up
					if(row <= 2 && column <= 3){
						boolean notOccupied = true;
						for(int i = 0; i < 4; i++){
							if(s.grid[column+i][row+i] == opponent){
								notOccupied = false;
								break;
							}else if(s.grid[column+i][row+i] == s.turn){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
					count = 0;
					//Check diagonal down
					if(row > 2 && column <= 3){
						boolean notOccupied = true;
						for(int i = 0; i < 4; i++){
							if(s.grid[column+i][row-i] == opponent){
								notOccupied = false;
								break;
							}else if(s.grid[column+i][row-i] == s.turn){
								count++;
							}
						}
						
						if(notOccupied) counts[count]++;
					}
					
				}
			}	
		}
			
		double value = 0;
		
		for(int i = 0; i < counts.length; i++){
			value += weights[i]*counts[i];
		}
		//System.out.println("Value: "+ value+" "+"Counts:"+Arrays.toString(counts));
		//System.out.println(s.toString());
		return value;
		
	}
	
	/**
	 * First utility function.
	 * For each field calculate the amount of neighbours with the player color.
	 * 
	 */
	public double easyUtility(State state){
		if(!(state instanceof ConnectFourState)) return Double.MAX_VALUE;
		ConnectFourState s = (ConnectFourState) state;
		
		/*
		 * Test function. 
		 */
		double value = 0;
		for(int column = 0; column < 7; column++){
			for(int row = 0; row < 6; row++){
				if(s.grid[column][row] == player){
					//Check left side
					if(column > 0){
						//Check bottom left
						if(row > 0){
							if(s.grid[column-1][row-1] == player) value += 1.0;
						}
						//Check left
						if(s.grid[column-1][row] == player ) value += 1.0;
						//Check top left
						if(row < 5){
							if(s.grid[column-1][row+1] == player) value += 1.0;
						}
					}
					//Check same column
					if(row > 0){
						if(s.grid[column][row-1] == player) value += 1.0;
					}
					if(row < 5){
						if(s.grid[column][row+1] == player) value += 1.0;
					}
					//Check right side
					if(column < 6){
						//Check bottom left
						if(row > 0){
							if(s.grid[column+1][row-1] == player) value += 1.0;
						}
						//Check left
						if(s.grid[column+1][row] == player) value += 1.0;
						//Check top left
						if(row < 5){
							if(s.grid[column+1][row+1] == player) value += 1.0;
						}
					}
				}else if(s.grid[column][row] == ConnectFourState.FieldState.EMPTY){
					//System.out.println("Empty");
					value += 0;
				}
				
			}
		}
		//System.out.println(value);
		//System.out.println(s.toString());
		return value;
	}
	
	private void initActions(){
		//First column
		actions.add(new Action() {
			
			@Override
			public String toString() {
				return "0";
			}
			
			@Override
			public State execute(State state) {
				
				if(!(state instanceof ConnectFourState)) return null;
				ConnectFourState s = (ConnectFourState) state;
				
				//Copy grid
				ConnectFourState.FieldState [][] grid = new ConnectFourState.FieldState[s.grid.length][];
				for(int j = 0; j < grid.length; j++){
				    grid[j] = s.grid[j].clone();
				}
				
				//Add color
				for(int j = 0; j < 6; j++){
					if(grid[0][j] == ConnectFourState.FieldState.EMPTY){
						if(s.turn == ConnectFourState.FieldState.RED){
							grid[0][j] = ConnectFourState.FieldState.YELLOW;
							return new ConnectFourState(grid, ConnectFourState.FieldState.YELLOW);
						}else{
							grid[0][j] = ConnectFourState.FieldState.RED;
							return new ConnectFourState(grid, ConnectFourState.FieldState.RED);
						}
					}
				}
				
				return null;
			}
		});
		
		actions.add(new Action() {
			
			@Override
			public String toString() {
				return "1";
			}
			
			@Override
			public State execute(State state) {
				
				if(!(state instanceof ConnectFourState)) return null;
				ConnectFourState s = (ConnectFourState) state;
				
				//Copy grid
				ConnectFourState.FieldState [][] grid = new ConnectFourState.FieldState[s.grid.length][];
				for(int j = 0; j < grid.length; j++){
					grid[j] = s.grid[j].clone();
				}
				
				//Add color
				for(int j = 0; j < 6; j++){
					if(grid[1][j] == ConnectFourState.FieldState.EMPTY){
						if(s.turn == ConnectFourState.FieldState.RED){
							grid[1][j] = ConnectFourState.FieldState.YELLOW;
							return new ConnectFourState(grid, ConnectFourState.FieldState.YELLOW);
						}else{
							grid[1][j] = ConnectFourState.FieldState.RED;
							return new ConnectFourState(grid, ConnectFourState.FieldState.RED);
						}
					}
				}
				
				return null;
			}
		});
		
		actions.add(new Action() {
			
			@Override
			public String toString() {
				return "2";
			}
			
			@Override
			public State execute(State state) {
				
				if(!(state instanceof ConnectFourState)) return null;
				ConnectFourState s = (ConnectFourState) state;
				
				//Copy grid
				ConnectFourState.FieldState [][] grid = new ConnectFourState.FieldState[s.grid.length][];
				for(int j = 0; j < grid.length; j++){
					grid[j] = s.grid[j].clone();
				}
				
				//Add color
				for(int j = 0; j < 6; j++){
					if(grid[2][j] == ConnectFourState.FieldState.EMPTY){
						if(s.turn == ConnectFourState.FieldState.RED){
							grid[2][j] = ConnectFourState.FieldState.YELLOW;
							return new ConnectFourState(grid, ConnectFourState.FieldState.YELLOW);
						}else{
							grid[2][j] = ConnectFourState.FieldState.RED;
							return new ConnectFourState(grid, ConnectFourState.FieldState.RED);
						}
					}
				}
				
				return null;
			}
		});
		
		actions.add(new Action() {
			
			@Override
			public String toString() {
				return "3";
			}
			
			@Override
			public State execute(State state) {
				
				if(!(state instanceof ConnectFourState)) return null;
				ConnectFourState s = (ConnectFourState) state;
				
				//Copy grid
				ConnectFourState.FieldState [][] grid = new ConnectFourState.FieldState[s.grid.length][];
				for(int j = 0; j < grid.length; j++){
					grid[j] = s.grid[j].clone();
				}
				
				//Add color
				for(int j = 0; j < 6; j++){
					if(grid[3][j] == ConnectFourState.FieldState.EMPTY){
						if(s.turn == ConnectFourState.FieldState.RED){
							grid[3][j] = ConnectFourState.FieldState.YELLOW;
							return new ConnectFourState(grid, ConnectFourState.FieldState.YELLOW);
						}else{
							grid[3][j] = ConnectFourState.FieldState.RED;
							return new ConnectFourState(grid, ConnectFourState.FieldState.RED);
						}
					}
				}
				
				return null;
			}
		});
		
		actions.add(new Action() {
			
			@Override
			public String toString() {
				return "4";
			}
			
			@Override
			public State execute(State state) {
				
				if(!(state instanceof ConnectFourState)) return null;
				ConnectFourState s = (ConnectFourState) state;
				
				//Copy grid
				ConnectFourState.FieldState [][] grid = new ConnectFourState.FieldState[s.grid.length][];
				for(int j = 0; j < grid.length; j++){
					grid[j] = s.grid[j].clone();
				}
				
				//Add color
				for(int j = 0; j < 6; j++){
					if(grid[4][j] == ConnectFourState.FieldState.EMPTY){
						if(s.turn == ConnectFourState.FieldState.RED){
							grid[4][j] = ConnectFourState.FieldState.YELLOW;
							return new ConnectFourState(grid, ConnectFourState.FieldState.YELLOW);
						}else{
							grid[4][j] = ConnectFourState.FieldState.RED;
							return new ConnectFourState(grid, ConnectFourState.FieldState.RED);
						}
					}
				}
				
				return null;
			}
		});
		
		actions.add(new Action() {
			
			@Override
			public String toString() {
				return "5";
			}
			
			@Override
			public State execute(State state) {
				
				if(!(state instanceof ConnectFourState)) return null;
				ConnectFourState s = (ConnectFourState) state;
				
				//Copy grid
				ConnectFourState.FieldState [][] grid = new ConnectFourState.FieldState[s.grid.length][];
				for(int j = 0; j < grid.length; j++){
					grid[j] = s.grid[j].clone();
				}
				
				//Add color
				for(int j = 0; j < 6; j++){
					if(grid[5][j] == ConnectFourState.FieldState.EMPTY){
						if(s.turn == ConnectFourState.FieldState.RED){
							grid[5][j] = ConnectFourState.FieldState.YELLOW;
							return new ConnectFourState(grid, ConnectFourState.FieldState.YELLOW);
						}else{
							grid[5][j] = ConnectFourState.FieldState.RED;
							return new ConnectFourState(grid, ConnectFourState.FieldState.RED);
						}
					}
				}
				
				return null;
			}
		});
		
		actions.add(new Action() {
			
			@Override
			public String toString() {
				return "6";
			}
			
			@Override
			public State execute(State state) {
				
				if(!(state instanceof ConnectFourState)) return null;
				ConnectFourState s = (ConnectFourState) state;
				
				//Copy grid
				ConnectFourState.FieldState [][] grid = new ConnectFourState.FieldState[s.grid.length][];
				for(int j = 0; j < grid.length; j++){
					grid[j] = s.grid[j].clone();
				}
				
				//Add color
				for(int j = 0; j < 6; j++){
					if(grid[6][j] == ConnectFourState.FieldState.EMPTY){
						if(s.turn == ConnectFourState.FieldState.RED){
							grid[6][j] = ConnectFourState.FieldState.YELLOW;
							return new ConnectFourState(grid, ConnectFourState.FieldState.YELLOW);
						}else{
							grid[6][j] = ConnectFourState.FieldState.RED;
							return new ConnectFourState(grid, ConnectFourState.FieldState.RED);
						}
					}
				}
				
				return null;
			}
		});


		
	}
}
